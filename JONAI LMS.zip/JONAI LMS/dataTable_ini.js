	$(document).ready(function() {
    $('#table_id').DataTable( {

        "bDestroy": true,
       
        dom: 'Bfrtip',
        
        buttons: [
            'copy', 'excel', 'print'
        ]
    });
});
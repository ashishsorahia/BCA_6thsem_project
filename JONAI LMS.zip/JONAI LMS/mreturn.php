<?php include("header.php"); ?>
 <?php 

$result=''; 
$host="localhost";
$user="root";
$password="";
$database="jonai";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
    $con=mysqli_connect($host, $user, $password, $database);
}catch (Exception $ex){
    echo'Error';
}
  if(isset($_POST['return']))

  {
    extract($_POST);
     
    
        
    $sql = "INSERT INTO `return`(`libid`, `bid`, `iid`, `idate`, `rdate`, `rmonth`) VALUES ('$libid','$bid','$iid','$idate','$rdate','$rmonth')";
    $res = $con->query($sql);
    if($res){
      //$msg="Send Successful";
   //header("Refresh:0");
     $result='<div class="alert alert-success">Book Returned Sucessfully</div>';   ;
    }else{
      echo "Data not Inserted";;
    }
  }
      
?>
<?php 
 $con=new mysqli("localhost", "root", "", "jonai");
 if(isset($_POST['return'])) 
    { 
        
           $UpdateQuery="UPDATE `book` set quantity='$_POST[add]' WHERE id='$_POST[bid]'";
           $res=$con->query($UpdateQuery);
           //header("Refresh:0;viewregistration.php");
    };

?>
<?php 
 $con=new mysqli("localhost", "root", "", "jonai");
 if(isset($_POST['return'])) 
    { 
        
           $UpdateQuery="UPDATE `issue` set status='Returned' WHERE iid='$_POST[iid]'";
           $res=$con->query($UpdateQuery);
           //header("Refresh:0;viewregistration.php");
    };

?>
  <!-- //header-ends -->
<!-- main content start -->
<div class="main-content">

    <!-- content -->
    <div class="container-fluid content-top-gap">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb my-breadcrumb">
                <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Manage return</li>
            </ol>
        </nav>
        <!-- //breadcrumbs -->
        <!-- forms -->
        <section class="forms">
            <!-- forms 1 -->
            <div class="card card_border py-2 mb-4">
                <div class="cards__heading">
                    <h3>return Book <span></span></h3>
                     <strong><?php echo $result; ?></strong>
                </div>
                <div class="card-body">
                   <form action="mreturn.php" method="POST">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Enter Library ID</label>
      
      <input type="text" class="form-control" id="libid" onchange="this.form.submit();" name="libid"  value="<?php echo isset($_POST['libid']) ? $_POST['libid'] : '' ?>">
    </div>
</form>
<table class="table">
  <thead>
    <tr>
      
      <th scope="col">Library Id</th>
      <th scope="col">Student Name</th>
      <th scope="col">Book Name</th>
      <th scope="col">Issue ID</th>
      <th scope="col">Issue Date</th>
      <th scope="col">Action</th>
      
      
    </tr>
  </thead>
  <?php 

                                        if(isset($_POST['libid'])){
                                            
                                        //$_POST['station_feature']="";
                                            //if(!empty($_POST['station_category'])||(!empty($_POST['station_feature']))||(!empty($_POST['station_name']))){
                                        
                                             //when no filter is selected
                                            if((isset($_POST['libid'])) && $_POST['libid']!=""):
                                                $libid = $_POST['libid']; 
                                                $sql="SELECT * from `issue` INNER JOIN `reg` ON issue.libid = reg.libid INNER JOIN `book` ON issue.bid = book.id WHERE issue.libid='$libid' AND issue.status='Issued'";
                                            endif;
                                            
                                            
                                            
                                                
                                         $run_q = mysqli_query($con, $sql);
                                            while($row  = mysqli_fetch_assoc($run_q)){
                                                
                                                
                                            
                                        ?>
                                        <tbody>
    <tr>
       
     <form action="" method="POST">
     <td><?php echo $row['libid']; ?><input type="hidden" name="libid" id="libid" value="<?php echo $row['libid']; ?>"></td>
     <td><?php echo $row['sname']; ?><input type="hidden" name="bid" id="bid" value="<?php echo $row['bid']; ?>"></td>
     <td><?php echo $row['bname']; ?><input type="hidden" name="iid" id="iid" value="<?php echo $row['iid']; ?>"></td>
     <td><?php echo $row['iid']; ?><input type="hidden" name="idate" id="idate" value="<?php echo $row['date']; ?>"></td>
     <td><?php echo $row['date']; ?> <input type="hidden" name="rdate" id="rdate" value="<?php echo date("m/d/Y"); ?>">
        <input type="hidden" name="rmonth" id="rmonth" value="<?php echo date("F"); ?>">
        <input type="hidden" name="quantity" value="<?php echo $row['quantity'] ?>">
        <?php $add="";
        $bquantity="";
        $bquantity=$row['quantity'];
      $add=$bquantity+1;

        ?>
         <input type="hidden" name="add" value="<?php echo $add; ?>">
     </td>
     
     <td><button type="submit" name="return" width=600,height=600; class="btn btn-primary">Return</a></td>
    </tr>
    </form>
  </tbody>
  <?php 
                  
                                            }
           
             }
                  
                  ?>
</table>
                </div>
            </div>
            <!-- //forms 1 -->

            <!-- forms 2 -->
            
            <!-- //forms 2 -->

            <!-- horizontal forms-->
            <!-- forms 3 -->
            
            <!-- //forms 3 -->
            <!-- //horizontal forms-->

            <!-- supported elements -->
            <!--  -->
            
            <!-- // -->
            <!-- supported elements -->

        </section>
        <!-- //forms -->
        </section>
        <!-- //forms  -->

    </div>
    <!-- //content -->

</div>
<!-- main content end-->
</section>
<!--footer section start-->
<?php include("footer.php"); ?>
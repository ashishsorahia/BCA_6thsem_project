<?php include("header.php"); ?>
<div class="main-content">
<script type = "text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};
</script>
  <!-- content -->
  <div class="container-fluid content-top-gap">

    <nav aria-label="breadcrumb">
      <ol class="breadcrumb my-breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
      </ol>
    </nav>
    <div class="welcome-msg pt-3 pb-4">
      <h1>Hi <span class="text-primary"><?php echo $username; ?></span>, Welcome </h1>
    </div>
    <div class="accordions">
      <div class="row">
        <!-- accordion style 1 -->
        <div class="col-lg-12 mb-4">
          <div class="card card_border">
            <div class="card-header chart-grid__header">
              Issue Record
            </div>
            <div class="card-body">
              <div class="accordion" id="accordionExample">
                <div class="card">
                  
                  <table class="table">
  <thead>
    <tr>
      
      <th scope="col">Book Name</th>
      <th scope="col">Student Name</th>
      <th scope="col">Phone No</th>
      <th scope="col">Month</th>
      <th scope="col">Date</th>
     
      
      
    </tr>
  </thead>
  <?php 
  $con=new mysqli("localhost","root","","jonai");

                                        
                                                $sql="SELECT * from `issue` INNER JOIN `book` ON issue.bid = book.id INNER JOIN `reg` ON issue.libid = reg.libid";
                                         
                                            
                                            
                                            
                                                
                                         $run_q = mysqli_query($con, $sql);
                                            while($row  = mysqli_fetch_assoc($run_q)){
                                                
                                                
                                            
                                        ?>
                                        <tbody>
    <tr>
       
     
     <td><?php echo $row['bname']; ?></td>
     <td><?php echo $row['sname']; ?></td>
     <td><?php echo $row['phone']; ?></td>
     <td><?php echo $row['month']; ?></td>
     <td><?php echo $row['date']; ?></td>
    </tr>
  </tbody>
  <?php 
                  
                                            }
           
             
                  
                  ?>
</table>
                </div>
              
              
              </div>
            </div>
          </div>
        </div>
        <!-- //accordion style 1 -->
      </div>
    </div>
    <!-- //accordions -->

    <!-- modals -->
    <!-- //modals -->

  </div>
  <!-- //content -->
</div>
<!-- main content end-->
</section>
  <!--footer section start-->
<?php include("footer.php"); ?>
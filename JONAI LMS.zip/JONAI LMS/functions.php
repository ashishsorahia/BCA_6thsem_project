<?php
include('db.php');

function get_course(){
          global $con;
          $earning_types_sql = 'SELECT DISTINCT category FROM book';
          $run_earning_types_sql = mysqli_query($con, $earning_types_sql);
          
          while($rows = mysqli_fetch_assoc($run_earning_types_sql))
          {
          
			echo "<option value=\"".$rows["category"]."\"";
             if(@$_POST['category'] == $rows['category'])
                    echo 'selected';
                   
              echo ">".$rows["category"]."</option>"; 
			
          } 
		  
}
?>  
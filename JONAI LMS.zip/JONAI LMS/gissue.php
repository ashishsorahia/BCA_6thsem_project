<?php include("header.php"); ?>
<?php 
//session_start();
$bname="";
$category="";
$aname="";
$pname="";
$isbnno="";
$quantity="";

$con = mysqli_connect('localhost', 'root', '', 'jonai');
if(isset($_GET['id']))
{
extract($_GET);



$_SESSION['sql']="SELECT * FROM `book` WHERE id='$id'";
                                            
                                             $searc = 1;
        }elseif ($_SESSION['sql']!="") {
            $searc = 1;
        }else{
            $searc = 0;
        }
?>    
<?php 
    if($searc==1){       
                                         $run_q = mysqli_query($con, $_SESSION['sql']);
                                            while($row  = mysqli_fetch_assoc($run_q)){
                                               $id=$row['id'];
                                               $bname=$row['bname'];
                                               $category=$row['category'];
                                               $aname=$row['aname'];
                                               $pname=$row['pname'];
                                               $isbnno=$row['isbnno'];
                                               $quantity=$row['quantity'];

                                               
                                            }
                                        }
                                        ?>
                                        <?php 

$result=''; 
$host="localhost";
$user="root";
$password="";
$database="jonai";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
    $con=mysqli_connect($host, $user, $password, $database);
}catch (Exception $ex){
    echo'Error';
}
  if(isset($_POST['insert']))

  {
    extract($_POST);
     
    $sql="SELECT * FROM `issue` WHERE libid='$libid' AND status='Issued'";
    $search_result = mysqli_query($con, $sql);
    if(mysqli_num_rows($search_result) > 0)
    {
       $result='<div class="alert alert-success">Already Issued a Book</div>'; 
    }else{
        
    $sql = "INSERT INTO `issue`(`libid`, `bid`, `status`, `month`, `date`) VALUES ('$libid','$bid','$status','$month','$date')";
    $res = $con->query($sql);
    if($res){
      //$msg="Send Successful";
   //header("Refresh:0");
     $result='<div class="alert alert-success">Book Issued Sucessfully</div>';   ;
    }else{
      echo "Data not Inserted";;
    }
  }
}
      
?>
<?php 
 $con=new mysqli("localhost", "root", "", "jonai");
 if(isset($_POST['insert'])) 
    { 
        
           $UpdateQuery="UPDATE `book` set quantity='$_POST[left]' WHERE id='$_POST[bid]'";
           $res=$con->query($UpdateQuery);
           //header("Refresh:0;viewregistration.php");
    };

?>

  <!-- //header-ends -->
<!-- main content start -->
<div class="main-content">
 <?php 
                    $msg="";
                    $libid="";
                                                    $sname="";
                                                    $email="";
                                                    $phone="";
                                                    $lid="";
                                                    $status="";
                                                    $con = new mysqli("localhost",'root','','jonai');
                                        if(isset($_POST['libid'])){
                                            $count = 1;
                                        //$_POST['station_feature']="";
                                            //if(!empty($_POST['station_category'])||(!empty($_POST['station_feature']))||(!empty($_POST['station_name']))){
                                        
                                             //when no filter is selected
                                            if((isset($_POST['libid'])) && $_POST['libid']!=""):
                                                $libid = $_POST['libid']; 
                                                $sql="SELECT * FROM reg WHERE libid='$libid' AND status='Approved'";
                                            endif;  
                                         $run_q = mysqli_query($con, $sql);
                                          if(mysqli_num_rows($run_q) ==0){
                                               $msg='<div class="alert alert-success">Library ID is not Apporved</div>';
                                            }else{
                                            while($row  = mysqli_fetch_assoc($run_q)){
                                               $sname=$row['sname'];
                                               $email=$row['email'];
                                               $phone=$row['phone'];
                                               $lid=$row['libid'];
                                               $status=$row['status'];
                                           }
                                       }
                                     }
                                            
                                        ?>
    <!-- content -->
    <div class="container-fluid content-top-gap">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb my-breadcrumb">
                <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Manage Book</li>
            </ol>
        </nav>
        <!-- //breadcrumbs -->
        <!-- forms -->
        <section class="forms">
            <!-- forms 1 -->
            <div class="card card_border py-2 mb-4">
                <div class="cards__heading">
                    <h3>Issue Book <span></span></h3>
                     <strong><?php echo $msg; ?></strong>
                      <strong><?php echo $result; ?></strong>
                </div>
                <div class="card-body">
                   <h4>Student Details</h4>
                   
                                        <form action="" method="POST">
                                        <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Student Library ID</label>
      <input type="hidden" name="bid" id="bid" value="<?php echo $id; ?>">
      <input type="text" class="form-control" id="libid" onchange="this.form.submit();" name="libid" placeholder="Enter Library ID" value="<?php echo isset($_POST['libid']) ? $_POST['libid'] : '' ?>">
<input type="hidden" name="lid" id="lid" value="<?php echo $lid; ?>">
<input type="hidden" name="status" id="stat" value="<?php echo $status; ?>">
    </div>
    
    <div class="form-group col-md-6">
      <label for="inputPassword4">Student Name</label>
      <input type="text" class="form-control" readonly id="sname" name="sname" value="<?php echo $sname; ?>">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputPassword4">Phone No.</label>
      <input type="text" class="form-control" readonly id="phone" name="phone" value="<?php echo $phone; ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputEmail4">Email ID:</label>
      <input type="text" class="form-control" readonly id="email" name="email" value="<?php echo $email;?>">
    </div>
    
  </div>
  <h4>Book Details</h4>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Book Name</label>
      
      <input type="text" class="form-control" id="bname" name="bname" readonly value="<?php echo $bname; ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Category</label>
      <input type="text" class="form-control" readonly id="category" name="category" value="<?php echo $category; ?>">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputPassword4">Author Name</label>
      <input type="text" class="form-control" readonly id="aname" name="aname" value="<?php echo $aname; ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputEmail4">Publisher Name:</label>
      <input type="text" class="form-control" readonly id="pname" name="pname" value="<?php echo $pname; ?>">
    </div>
    
      <input type="hidden" class="form-control" readonly id="quantity" name="quantity" value="<?php echo $quantity; ?>">
      <?php $left="";
      $left=$quantity-1;

        ?>
      <input type="hidden" name="status" value="Issued">
      <input type="hidden" name="left" value="<?php echo $left; ?>">
      <input type="hidden" name="month" value="<?php echo date("F"); ?>">
      <input type="hidden" name="date" value="<?php echo date("m/d/Y"); ?>">
    
    
  </div>
                </div>
            </div>
          <?php if ($libid && $row['status']=="Applied"){ ?>
            <button type="button" class="btn btn-danger">Sorry! Cannot Issue a Book</button>
<?php }else{ ?>
             <button type="submit" name="insert" class="btn btn-primary">Issue</button>
         <?php } ?>
            </form>
  
            <!-- //forms 1 -->

            <!-- forms 2 -->
            
            <!-- //forms 2 -->

            <!-- horizontal forms-->
            <!-- forms 3 -->
            
            <!-- //forms 3 -->
            <!-- //horizontal forms-->

            <!-- supported elements -->
            <!--  -->
            
            <!-- // -->
            <!-- supported elements -->

        </section>
        <!-- //forms -->
        </section>
        <!-- //forms  -->

    </div>
    <!-- //content -->

</div>
<!-- main content end-->
</section>
<!--footer section start-->
<?php include("footer.php"); ?>
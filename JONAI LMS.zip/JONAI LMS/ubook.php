<?php include("header.php"); ?>
<?php 

include('functions.php'); 

?>
<?php  
$result='';
  if(isset($_POST['update'])){
    
    extract($_POST);
    $mysqli = new mysqli("localhost",'root','','jonai');
    $sql = "UPDATE `book` SET bname='$bname',category='$category',aname='$aname',pname='$pname',isbnno='$isbnno',quantity='$quantity' WHERE id='$id'";
    $res = $mysqli->query($sql);
    if($res){
      //header("location: index.php");
         $result='<div class="alert alert-success">Book Updated Succesfully</div>';

    }
  }
?>
<?php  
$result='';
  if(isset($_POST['delete'])){
    
    extract($_POST);
    $mysqli = new mysqli("localhost",'root','','jonai');
    $sql = "DELETE FROM `book` WHERE id='$id'";
    $res = $mysqli->query($sql);
    if($res){
      //header("location: index.php");
         $result='<div class="alert alert-success">Book Deleted Succesfully</div>';

    }
  }
?>
  <!-- //header-ends -->
<!-- main content start -->
<script type="text/javascript">
  
function lettersValidate(key) {
    var e = event || evt;
    var charCode = e.which || e.keyCode;
    if ((charCode >= 48) && (charCode <= 57))
       return false;
    return true;
         
}

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
<div class="main-content">

    <!-- content -->
    <div class="container-fluid content-top-gap">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb my-breadcrumb">
                <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Manage Book</li>
            </ol>
        </nav>
        <!-- //breadcrumbs -->
        <!-- forms -->
        <section class="forms">
            <!-- forms 1 -->
            <div class="card card_border py-2 mb-4">
                <div class="cards__heading">
                    <h3>Update Book <span></span></h3>
                     <strong><?php echo $result; ?></strong>
                </div>
                <div class="card-body">
                   <form action="ubook.php" method="POST">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Book Category*</label>
      <select class="form-control" name="category" id="category" onchange="this.form.submit()">
    <option>Select Any</option>
     <?php get_course(); ?>
  </select>
    </div>
</form>

<table class="table">
  <thead>
    <tr>
      
      <th scope="col">Book Name</th>
      <th scope="col">Category</th>
      <th scope="col">Author Name</th>
      <th scope="col">Publisher Name</th>
      <th scope="col">ISBN No.</th>
      <th scope="col">Quantity</th>
      <th scope="col">Action 1</th>
      <th scope="col">Action 2</th>
      
    </tr>
  </thead>
  <?php 

                                        if(isset($_POST['category'])){
                                            
                                        //$_POST['station_feature']="";
                                            //if(!empty($_POST['station_category'])||(!empty($_POST['station_feature']))||(!empty($_POST['station_name']))){
                                        
                                             //when no filter is selected
                                            if((isset($_POST['category'])) && $_POST['category']!=""):
                                                $category = $_POST['category']; 
                                                $sql="SELECT * from book WHERE category='$category'";
                                            endif;
                                            
                                            
                                            
                                                
                                         $run_q = mysqli_query($con, $sql);
                                            while($row  = mysqli_fetch_assoc($run_q)){
                                                
                                                
                                            
                                        ?>
                                        <tbody>
    <tr>
       
     
     <td><?php echo $row['bname']; ?></td>
     <td><?php echo $row['category']; ?></td>
     <td><?php echo $row['aname']; ?></td>
     <td><?php echo $row['pname']; ?></td>
     <td><?php echo $row['isbnno']; ?></td>
     <td><?php echo $row['quantity']; ?></td>
     <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal-<?php echo $row['id'] ?>">
  Edit
</button>
<div class="modal fade" id="exampleModal-<?php echo $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel-<?php echo $row['id'] ?>" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel-<?php echo $row['id'] ?>">Edit Course</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
    
        <form action="ubook.php" method="POST" enctype="multipart/form-data">
      <div class="modal-body">
    
         
             <div class="form-group">
            <label for="in">Book Name: </label><br>
            <input type="text" class="form-control" name="bname" id="bname-<?php echo $row['id'] ?>" value="<?php echo $row['bname'] ?>" onkeypress="return lettersValidate(event)">
            <input type="hidden" class="form-control" name="id" id="id-<?php echo $row['id'] ?>" value="<?php echo $row['id'] ?>">
       </div> <!-- /form-group-->            
          <div class="form-group">
            <label for="qty">Category: </label><br>
           <select id="category" name="category" class="form-control" required>
        <option selected>Select Any</option>
        <option value="Computer Science">Computer Science</option>
        <option value="Mathematics">Mathematics</option>
        <option value="Chemistry">Chemistry</option>
        <option value="Physics">Physics</option>
        <option value="Biology">Biology</option>
      </select>
          </div>
      <div class="form-group">
            <label for="qty">Autor Name: </label><br>
               <input type="text" class="form-control" name="aname" id="aname-<?php echo $row['id'] ?>" value="<?php echo $row['aname'] ?>" onkeypress="return lettersValidate(event)">
          </div>
       <div class="form-group">
            <label for="qty">Publisher Name: </label><br>
              <input type="text" class="form-control" name="pname" id="pname-<?php echo $row['id'] ?>" value="<?php echo $row['pname'] ?>" onkeypress="return lettersValidate(event)">
          </div>
          <div class="form-group">
            <label for="qty">ISBN No: </label><br>
              <input type="text" class="form-control" name="isbnno" id="isbnno-<?php echo $row['id'] ?>" value="<?php echo $row['isbnno'] ?>" maxlength="13" onkeypress="return isNumber(event);">
          </div>
           <div class="form-group">
            <label for="qty">Quantity: </label><br>
              <input type="text" class="form-control" name="quantity" id="quantity-<?php echo $row['id'] ?>" value="<?php echo $row['quantity'] ?>" onkeypress="return isNumber(event);">
          </div>      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" name="update" class="btn btn-primary" value="Update">
    
      </div>
    </div>
  </form>
      </div>
     
   
</div>

 
              </div>


</td>
<form action="ubook.php" method="POST"> 
<input type="hidden" class="form-control" name="id" id="id-<?php echo $row['id'] ?>" value="<?php echo $row['id'] ?>"> 
<td><button type="submit" class="btn btn-primary" name="delete" id="delete-<?php echo $row['id'] ?>">Delete</button></td>
</form>
    </tr>
  </tbody>
  <?php 
                  
                                            }
           
             }
                  
                  ?>
</table>
                </div>
            </div>
            <!-- //forms 1 -->

            <!-- forms 2 -->
            
            <!-- //forms 2 -->

            <!-- horizontal forms-->
            <!-- forms 3 -->
            
            <!-- //forms 3 -->
            <!-- //horizontal forms-->

            <!-- supported elements -->
            <!--  -->
            
            <!-- // -->
            <!-- supported elements -->

        </section>
        <!-- //forms -->
        </section>
        <!-- //forms  -->

    </div>
    <!-- //content -->

</div>
<!-- main content end-->
</section>
<!--footer section start-->
<?php include("footer.php"); ?>
<?php 

$n = 3;
function getRandomString($n)
{
  $characters = '0123456789ABCDEF';
  $randomString = 'JSC-';

  for ($i = 0; $i < $n; $i++) {
    $index = rand(0, strlen($characters) - 1);
    $randomString .= $characters[$index];
  }

  return $randomString;
}
?>
<?php 
$libid="";
$result=''; 
$host="localhost";
$user="root";
$password="";
$database="jonai";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
    $con=mysqli_connect($host, $user, $password, $database);
}catch (Exception $ex){
    echo'Error';
}
  if(isset($_POST['insert']))

  {
      $libid=$_POST['libid'];
        $sname=$_POST['sname'];
          $email=$_POST['email'];
            $phone=$_POST['phone'];
            $status=$_POST['status'];
            
              
    $sql="SELECT * FROM `reg` WHERE email='$email'";
    $search_result = mysqli_query($con, $sql);
    if(mysqli_num_rows($search_result) > 0)
    {
       $result='<div class="alert alert-success">Already Resgistered</div>'; 
    }else{
    $sql = "INSERT INTO `reg`(`libid`, `sname`, `email`, `phone`, `status`) VALUES ('$libid','$sname','$email','$phone','$status')";
    $res = $con->query($sql);
    if($res){
        $result='<div class="alert alert-success">Succesfully Enrolled. Your Library ID is </div>';
    }else{
      echo "Data not Inserted";;
    }
  }
}
      
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Slot Coming Soon Responsive Widget Template :: W3layouts</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords"
        content="Slot Coming Soon Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template" />
    <!-- //Meta tag Keywords -->
    <link href="//fonts.googleapis.com/css2?family=Hind:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="//fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <!--/Style-CSS -->
    <link rel="stylesheet" href="student/css/style.css" type="text/css" media="all" />
    <!--//Style-CSS -->

    <link rel="stylesheet" href="student/css/font-awesome.min.css" type="text/css" media="all">
    <script type="text/javascript">
        function lettersValidate(key) {
    var e = event || evt;
    var charCode = e.which || e.keyCode;
    if ((charCode >= 48) && (charCode <= 57))
       return false;
    return true;
         
}
function isNumber(e){
    e = e || window.event;
    var charCode = e.which ? e.which : e.keyCode;
    return /\d/.test(String.fromCharCode(charCode));
}
    </script>
</head>

<body>
    <div id="block" class="w3lvide-content" data-vide-bg="student/images/slot" data-vide-options="position: 0% 50%">
        <div class="wrapper">
            <div class="workinghny-form-grid">
                <div class="slot-w3l-comingsoon">
                    <div class="slot-w3content">
                        <h3>Welcome to Jonai science College</h3>
                        <h1>Library System</h1>
                        <p class="text-5 text-light mb-3">Please Register Yourself</p>
                        
                            
                    </div>
                </div>
                <!-- /form -->
                <div class="main-hotair">
                    <div class="content-wthree">
                        <h2>Register here...</h2>
                        <strong><?php echo $result; echo $libid; ?> </strong>
                        <form action="registration.php" method="post" class="signin-form">
                            <div class="input-grids">
                                <label>Your Library Id:</label>
                                <input type="text" name="libid" id="libid" class="contact-input" value="<?php echo getRandomString($n); ?>" readonly />
                              <input type="text" name="sname" onkeypress="return lettersValidate(event)" style="text-transform: uppercase" required id="sname" placeholder="Enter Your Name*" class="contact-input" autofocus
                                required="" />
                              <input type="email" name="email" required id="email" placeholder="Enter Your Email*" class="contact-input" autofocus
                                required="" />
                                <input type="text" name="phone" required onkeypress="return isNumber(event);" id="phone" placeholder="Enter Your Phone Number*" class="contact-input" autofocus maxlength="10" 
                                required="" />
                                <input type="hidden" name="status" id="status" value="Applied">
                        </div>
                            <button class="btn" type="submit" name="insert">Submit</button><br>
                            <br>
                            <center><a href="index.php" class="btn btn-primary"  name="insert">Go to Home</a></center>
                            

                            
                       
                        </form>
                        
                    </div>

                </div>
                <!-- //form -->
            </div>
           <!-- copyright-->
           <div class="copyright text-center">

           </div>
         </div>
    </div>
    <script src="student/js/jquery.min.js"></script>
    <!-- //js -->
    <script src="student/js/jquery.vide.js"></script>
    <script>
    </script>
</body>

</html>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<?php 
session_start();
$username = $_SESSION['username'];
?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>JONAI College, LMS</title>

  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style-starter.css">
  
  <link rel="stylesheet" href="assets/css/buttons.dataTables.min.css">
  <!-- google fonts -->
  <link href="//fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900&display=swap" rel="stylesheet">
</head>

<body class="sidebar-menu-collapsed">
  <div class="se-pre-con"></div>
<section>
  <!-- sidebar menu start -->
  <div class="sidebar-menu sticky-sidebar-menu">

    <!-- logo start -->
    <div class="logo">
      <h1><a href="index.html">JONAI LMS</a></h1>
    </div>

  

    <div class="logo-icon text-center">
      <a href="index.html" title="logo"><img src="assets/images/logo.png" alt="logo-icon"> </a>
    </div>
    <!-- //logo end -->

    <div class="sidebar-menu-inner">

      <!-- sidebar nav start -->
      <ul class="nav nav-pills nav-stacked custom-nav">
        <li class="active"><a href="admin.php"><i class="fa fa-tachometer"></i><span> Dashboard</span></a>
        </li>
        <li class="menu-list">
          <a href="#"><i class="fa fa-cogs"></i>
            <span>Manage Book <i class="lnr lnr-chevron-right"></i></span></a>
          <ul class="sub-menu-list">
            <li><a href="mbook.php">Add</a> </li>
            <li><a href="ubook.php">Update</a> </li>
          </ul>
        </li>
        <li><a href="missue.php"><i class="fa fa-cogs"></i><span>Manage Issue</span></a></li>
         <li><a href="mreturn.php"><i class="fa fa-cogs"></i><span>Manage Return</span></a></li>
        
      
        <li><a href="approvereg.php"><i class="fa fa-table"></i> <span>Approve Registration</span></a></li>
        <li><a href="vissue.php"><i class="fa fa-file-text"></i> <span>View Issue Data</span></a></li>
        <li><a href="vreturn.php"><i class="fa fa-file-text"></i> <span>View Return Data</span></a></li>
        <li><a href="logout.php"><i class="fa fa-user"></i> <span>Logout</span></a></li>
      </ul>
      <!-- //sidebar nav end -->
      <!-- toggle button start -->
      <a class="toggle-btn">
        <i class="fa fa-angle-double-left menu-collapsed__left"><span>Collapse Sidebar</span></i>
        <i class="fa fa-angle-double-right menu-collapsed__right"></i>
      </a>
      <!-- //toggle button end -->
    </div>
  </div>
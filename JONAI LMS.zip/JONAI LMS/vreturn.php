<?php include("header.php"); ?>
 <?php 

$result=''; 
$host="localhost";
$user="root";
$password="";
$database="jonai";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
    $con=mysqli_connect($host, $user, $password, $database);
}catch (Exception $ex){
    echo'Error';
}
  if(isset($_POST['return']))

  {
    extract($_POST);
     
    
        
    $sql = "INSERT INTO `return`(`libid`, `bid`, `iid`, `idate`, `rdate`, `rmonth`) VALUES ('$libid','$bid','$iid','$idate','$rdate','$rmonth')";
    $res = $con->query($sql);
    if($res){
      //$msg="Send Successful";
   //header("Refresh:0");
     $result='<div class="alert alert-success">Book Returned Sucessfully</div>';   ;
    }else{
      echo "Data not Inserted";;
    }
  }
      
?>
<?php 
 $con=new mysqli("localhost", "root", "", "jonai");
 if(isset($_POST['return'])) 
    { 
        
           $UpdateQuery="UPDATE `book` set quantity='$_POST[add]' WHERE id='$_POST[bid]'";
           $res=$con->query($UpdateQuery);
           //header("Refresh:0;viewregistration.php");
    };

?>
<?php 
 $con=new mysqli("localhost", "root", "", "jonai");
 if(isset($_POST['return'])) 
    { 
        
           $UpdateQuery="UPDATE `issue` set status='Returned' WHERE iid='$_POST[iid]'";
           $res=$con->query($UpdateQuery);
           //header("Refresh:0;viewregistration.php");
    };

?>
  <!-- //header-ends -->
<!-- main content start -->
<div class="main-content">

    <!-- content -->
    <div class="container-fluid content-top-gap">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb my-breadcrumb">
                <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Return Data</li>
            </ol>
        </nav>
        <!-- //breadcrumbs -->
        <!-- forms -->
        <section class="forms">
            <!-- forms 1 -->
            <div class="card card_border py-2 mb-4">
                <div class="cards__heading">
                    <h3>View Return Record <span></span></h3>
                   
                </div>
                <div class="card-body">
                  
<table class="table" id="table_id">
  <thead>
    <tr>
      
      <th scope="col">Library Id</th>
      <th scope="col">Student Name</th>
      <th scope="col">Book Name</th>
      <th scope="col">Issue ID</th>
      <th scope="col">Issue Date</th>
      <th scope="col">Return Date</th>
     
      
      
    </tr>
  </thead>
  
                                        <tbody>
                                            <?php 

                                        
                                                $sql="SELECT * from `return` INNER JOIN `reg` ON return.libid = reg.libid INNER JOIN `book` ON return.bid = book.id";
                                           
                                            
                                            
                                                
                                         $run_q = mysqli_query($con, $sql);
                                            while($row  = mysqli_fetch_assoc($run_q)){
                                                
                                                
                                            
                                        ?>
    <tr>
       
     <form action="" method="POST">
     <td><?php echo $row['libid']; ?></td>
     <td><?php echo $row['sname']; ?></td>
     <td><?php echo $row['bname']; ?></td>
     <td><?php echo $row['iid']; ?></td>
      <td><?php echo $row['idate']; ?></td>
     <td><?php echo $row['rdate']; ?></td>
    </tr>
    </form>
    <?php 
                  
                                            }
           
            
                  
                  ?>
  </tbody>
  
</table>
                </div>
            </div>
            <!-- //forms 1 -->

            <!-- forms 2 -->
            
            <!-- //forms 2 -->

            <!-- horizontal forms-->
            <!-- forms 3 -->
            
            <!-- //forms 3 -->
            <!-- //horizontal forms-->

            <!-- supported elements -->
            <!--  -->
            
            <!-- // -->
            <!-- supported elements -->

        </section>
        <!-- //forms -->
        </section>
        <!-- //forms  -->

    </div>
    <!-- //content -->

</div>
<!-- main content end-->
</section>
<!--footer section start-->
<?php include("footer.php"); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.css">
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.js"></script>
<script type="text/javascript">
    $(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
<script type="text/javascript" src="ex/dataTables.buttons.min.js"></script>
    
    <script type="text/javascript" src="ex/pdfmake.min.js"></script>
    <script type="text/javascript" src="ex/buttons.html5.min.js"></script>
    <script type="text/javascript" src="ex/buttons.print.min.js"></script>
    <script type="text/javascript" src="ex/jszip.min.js"></script>
    <script type="text/javascript" src="ex/vfs_fonts.js"></script>
<script src="dataTable_ini.js"></script>
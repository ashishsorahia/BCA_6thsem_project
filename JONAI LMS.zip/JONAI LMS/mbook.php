<?php include("header.php"); ?>
<?php  
$result='';
  if(isset($_POST['insert'])){
    
    extract($_POST);
    $mysqli = new mysqli("localhost",'root','','jonai');
     $sql="SELECT * FROM `book` WHERE isbnno='$isbnno'";
    $res = $mysqli->query($sql);
    if(mysqli_num_rows($res) > 0)
    {
       $result='<div class="alert alert-success">Sorry! Duplicate ISBN Number. Please add different ISBN Number</div>'; 
    }else{
    $sql = "INSERT INTO `book`(`bname`, `category`, `aname`, `pname`, `isbnno`, `quantity`) VALUES ('$bname','$category','$aname','$pname','$isbnno','$quantity')";
    $res = $mysqli->query($sql);
    if($res){
      //header("location: index.php");
         $result='<div class="alert alert-success">Data Entered Succesfully</div>';

    }
  }
}
?>
<script type="text/javascript">
  
function lettersValidate(key) {
    var e = event || evt;
    var charCode = e.which || e.keyCode;
    if ((charCode >= 48) && (charCode <= 57))
       return false;
    return true;
         
}

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
  <!-- //header-ends -->
<!-- main content start -->
<div class="main-content">

    <!-- content -->
    <div class="container-fluid content-top-gap">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb my-breadcrumb">
                <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Manage Book</li>
            </ol>
        </nav>
        <!-- //breadcrumbs -->
        <!-- forms -->
        <section class="forms">
            <!-- forms 1 -->
            <div class="card card_border py-2 mb-4">
                <div class="cards__heading">
                    <h3>Add Book <span></span></h3>
                     <strong><?php echo $result; ?></strong>
                </div>
                <div class="card-body">
                   <form action="mbook.php" method="POST">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Book Name*</label>
      <input type="text" class="form-control" id="bname" style="text-transform: uppercase" required name="bname" onkeypress="return lettersValidate(event)" required>
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Category*</label>
      <select id="category" name="category" class="form-control" required>
        <option selected>Select Any</option>
        <option value="Computer Science">Computer Science</option>
        <option value="Mathematics">Mathematics</option>
        <option value="Chemistry">Chemistry</option>
        <option value="Physics">Physics</option>
        <option value="Biology">Biology</option>
      </select>
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Author Name*</label>
      <input type="text" class="form-control" style="text-transform: uppercase" id="aname" name="aname" onkeypress="return lettersValidate(event)" required>
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Publisher Name*</label>
      <input type="text" class="form-control" style="text-transform: uppercase" onkeypress="return lettersValidate(event)" id="pname" name="pname" required>
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">ISBN No.*</label>
      <input type="text" class="form-control" id="isbnno" onkeypress="return isNumber(event);" maxlength="13" name="isbnno" required>
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Quantity*</label>
      <input type="text" class="form-control" id="quantity" onkeypress="return isNumber(event);" name="quantity" required>
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
  <button type="submit" name="insert" class="btn btn-primary">Submit</button>
</div>
</div>
</form>
                </div>
            </div>
            <!-- //forms 1 -->

            <!-- supported elements -->

        </section>
        <!-- //forms -->
        </section>
        <!-- //forms  -->

    </div>
    <!-- //content -->

</div>
<!-- main content end-->
</section>
<!--footer section start-->
<?php include("footer.php"); ?>
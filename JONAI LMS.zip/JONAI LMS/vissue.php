<?php include("header.php"); ?>
 <?php 

$result=''; 
$host="localhost";
$user="root";
$password="";
$database="jonai";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
    $con=mysqli_connect($host, $user, $password, $database);
}catch (Exception $ex){
    echo'Error';
}
  if(isset($_POST['return']))

  {
    extract($_POST);
     
    
        
    $sql = "INSERT INTO `return`(`libid`, `bid`, `iid`, `idate`, `rdate`, `rmonth`) VALUES ('$libid','$bid','$iid','$idate','$rdate','$rmonth')";
    $res = $con->query($sql);
    if($res){
      //$msg="Send Successful";
   //header("Refresh:0");
     $result='<div class="alert alert-success">Book Returned Sucessfully</div>';   ;
    }else{
      echo "Data not Inserted";;
    }
  }
      
?>
<?php 
 $con=new mysqli("localhost", "root", "", "jonai");
 if(isset($_POST['return'])) 
    { 
        
           $UpdateQuery="UPDATE `book` set quantity='$_POST[add]' WHERE id='$_POST[bid]'";
           $res=$con->query($UpdateQuery);
           //header("Refresh:0;viewregistration.php");
    };

?>
<?php 
 $con=new mysqli("localhost", "root", "", "jonai");
 if(isset($_POST['return'])) 
    { 
        
           $UpdateQuery="UPDATE `issue` set status='Returned' WHERE iid='$_POST[iid]'";
           $res=$con->query($UpdateQuery);
           //header("Refresh:0;viewregistration.php");
    };

?>
  <!-- //header-ends -->
<!-- main content start -->
<div class="main-content">

    <!-- content -->
    <div class="container-fluid content-top-gap">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb my-breadcrumb">
                <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Issue Data</li>
            </ol>
        </nav>
        <!-- //breadcrumbs -->
        <!-- forms -->
        <section class="forms">
            <!-- forms 1 -->
            <div class="card card_border py-2 mb-4">
                <div class="cards__heading">
                    <h3>View Issue Record <span></span></h3>
                   
                </div>
                <div class="card-body">
                  
<table  id="table_id">
  <thead>
    <tr>
      
      <th>Library Id</th>
      <th>Student Name</th>
      <th>Book Name</th>
      <th>Issue ID</th>
      <th>Issue Date</th>
     
      
      
    </tr>
  </thead>
   <tbody>
    <?php 
$localhost = "localhost";
$username = "root";
$password = "";
$dbname = "jonai";

// db connection
$con = new mysqli($localhost, $username, $password, $dbname);
// check connection
if($con->connect_error) {
  die("Connection Failed : " . $connect->connect_error);
} else {
  // echo "Successfully connected";
}

      
                                        
                                                $sql="SELECT * from `issue` INNER JOIN `reg` ON issue.libid = reg.libid INNER JOIN `book` ON issue.bid = book.id WHERE issue.status='Issued'";
                                           
                                            
                                            
                                                
                                         $run_q = mysqli_query($con, $sql);
                                            while($row  = mysqli_fetch_assoc($run_q)){
                                                
                                                
                                            
                                        ?>
    <tr>
       
     <form action="" method="POST">
     <td><?php echo $row['libid']; ?></td>
     <td><?php echo $row['sname']; ?></td>
     <td><?php echo $row['bname']; ?></td>
     <td><?php echo $row['iid']; ?></td>
     <td><?php echo $row['date']; ?></td>
    </tr>
    </form>
    <?php 
                  
                                            }
           
            
                  
                  ?>
  </tbody>
  
</table>
                </div>
            </div>
            <!-- //forms 1 -->

            <!-- forms 2 -->
            
            <!-- //forms 2 -->

            <!-- horizontal forms-->
            <!-- forms 3 -->
            
            <!-- //forms 3 -->
            <!-- //horizontal forms-->

            <!-- supported elements -->
            <!--  -->
            
            <!-- // -->
            <!-- supported elements -->

        </section>
        <!-- //forms -->
        </section>
        <!-- //forms  -->

    </div>
    <!-- //content -->

</div>
<!-- main content end-->
</section>
<!--footer section start-->
<?php include("footer.php"); ?>
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.css" />
  
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.js"></script>

<script type="text/javascript" src="js/dataTables.buttons.min.js"></script>
    
   <link rel="stylesheet" type="text/css" href="css/buttons.dataTables.min.css">
    <script type="text/javascript" src="js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="js/buttons.flash.min.js"></script>
    <script type="text/javascript" src="js/pdfmake.min.js"></script>
    <script type="text/javascript" src="js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="js/buttons.print.min.js"></script>
    <script type="text/javascript" src="js/jszip.min.js"></script>
    <script type="text/javascript" src="js/vfs_fonts.js"></script>
<script src="dataTable_ini.js"></script>
<script type="text/javascript">
     $(document).ready( function () {
     $('#table_id').DataTable( {

        "bDestroy": true,
       
        dom: 'Bfrtip',
        
        buttons: [
            'copy', 'excel', 'print'
        ]
    });

} );
</script>

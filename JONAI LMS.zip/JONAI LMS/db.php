<?php 
    $server = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'jonai';
    $con = mysqli_connect($server, $user, $pass, $db);
?>
<?php include("header.php"); ?>
<?php 

include('functions.php'); 

?>
<?php  
$result='';
  if(isset($_POST['update'])){
    
    extract($_POST);
    $mysqli = new mysqli("localhost",'root','','jonai');
    $sql = "UPDATE `book` SET bname='$bname',category='$category',aname='$aname',pname='$pname',isbnno='$isbnno',quantity='$quantity' WHERE id='$id'";
    $res = $mysqli->query($sql);
    if($res){
      //header("location: index.php");
         $result='<div class="alert alert-success">Book Updated Succesfully</div>';

    }
  }
?>
<?php  
$result='';
  if(isset($_POST['delete'])){
    
    extract($_POST);
    $mysqli = new mysqli("localhost",'root','','jonai');
    $sql = "DELETE FROM `book` WHERE id='$id'";
    $res = $mysqli->query($sql);
    if($res){
      //header("location: index.php");
         $result='<div class="alert alert-success">Book Deleted Succesfully</div>';

    }
  }
?>
  <!-- //header-ends -->
<!-- main content start -->
<div class="main-content">

    <!-- content -->
    <div class="container-fluid content-top-gap">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb my-breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Manage issue</li>
            </ol>
        </nav>
        <!-- //breadcrumbs -->
        <!-- forms -->
        <section class="forms">
            <!-- forms 1 -->
            <div class="card card_border py-2 mb-4">
                <div class="cards__heading">
                    <h3>Issue Book <span></span></h3>
                     <strong><?php echo $result; ?></strong>
                </div>
                <div class="card-body">
                   <form action="missue.php" method="POST">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Enter ISBN No.</label>
      
      <input type="text" class="form-control" id="isbnno" onchange="this.form.submit();" name="isbnno"  value="<?php echo isset($_POST['isbnno']) ? $_POST['isbnno'] : '' ?>">
    </div>
</form>

<table class="table">
  <thead>
    <tr>
      
      <th scope="col">Book Name</th>
      <th scope="col">Category</th>
      <th scope="col">Author Name</th>
      <th scope="col">Publisher Name</th>
      <th scope="col">ISBN No.</th>
      <th scope="col">Quantity</th>
      <th scope="col">Action</th>
      
      
    </tr>
  </thead>
  <?php 

                                        if(isset($_POST['isbnno'])){
                                            
                                        //$_POST['station_feature']="";
                                            //if(!empty($_POST['station_category'])||(!empty($_POST['station_feature']))||(!empty($_POST['station_name']))){
                                        
                                             //when no filter is selected
                                            if((isset($_POST['isbnno'])) && $_POST['isbnno']!=""):
                                                $isbnno = $_POST['isbnno']; 
                                                $sql="SELECT * from `book` WHERE isbnno='$isbnno'";
                                            endif;
                                            
                                            
                                            
                                                
                                         $run_q = mysqli_query($con, $sql);
                                            while($row  = mysqli_fetch_assoc($run_q)){
                                                
                                                
                                            
                                        ?>
                                        <tbody>
    <tr>
       
     
     <td><?php echo $row['bname']; ?></td>
     <td><?php echo $row['category']; ?></td>
     <td><?php echo $row['aname']; ?></td>
     <td><?php echo $row['pname']; ?></td>
     <td><?php echo $row['isbnno']; ?></td>
     <td><?php echo $row['quantity']; ?></td>
     <td><a href="gissue.php?id=<?php echo $row['id'];?>" width=600,height=600; class="btn btn-primary">Issue</a></td>
    </tr>
  </tbody>
  <?php 
                  
                                            }
           
             }
                  
                  ?>
</table>
                </div>
            </div>
            <!-- //forms 1 -->

            <!-- forms 2 -->
            
            <!-- //forms 2 -->

            <!-- horizontal forms-->
            <!-- forms 3 -->
            
            <!-- //forms 3 -->
            <!-- //horizontal forms-->

            <!-- supported elements -->
            <!--  -->
            
            <!-- // -->
            <!-- supported elements -->

        </section>
        <!-- //forms -->
        </section>
        <!-- //forms  -->

    </div>
    <!-- //content -->

</div>
<!-- main content end-->
</section>
<!--footer section start-->
<?php include("footer.php"); ?>
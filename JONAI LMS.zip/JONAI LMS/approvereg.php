<?php include("header.php"); ?>
<?php 

include('functions.php'); 

?>
<?php  
$result='';
  if(isset($_POST['status'])){
    
    extract($_POST);
    $mysqli = new mysqli("localhost",'root','','jonai');
    $sql = "UPDATE `reg` SET status='$status' WHERE libid='$libid'";
    $res = $mysqli->query($sql);
    if($_POST['status']=="Approved"){
      //header("location: index.php");
         $result='<div class="alert alert-success">Library ID Approved Successfully</div>';

    }else{
      $result='<div class="alert alert-success">Library ID Rejected Successfully</div>';
    }
  }
?>
  <!-- //header-ends -->
<!-- main content start -->
<div class="main-content">

    <!-- content -->
    <div class="container-fluid content-top-gap">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb my-breadcrumb">
                <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Approve Registration</li>
            </ol>
        </nav>
        <!-- //breadcrumbs -->
        <!-- forms -->
        <section class="forms">
            <!-- forms 1 -->
            <div class="card card_border py-2 mb-4">
                <div class="cards__heading">
                    <h3>Approve Registration<span></span></h3>
                     <strong><?php echo $result; ?></strong>
                </div>
                <div class="card-body">
                  
<table class="table">
  <thead>
    <tr>
      
      <th scope="col">Library ID</th>
      <th scope="col">Student Name</th>
      <th scope="col">Email</th>
      <th scope="col">Phone Number</th>
      <th scope="col">Status</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <?php 

                                                $sql="SELECT * from `reg`";    
                                         $run_q = mysqli_query($con, $sql);
                                            while($row  = mysqli_fetch_assoc($run_q)){   
                                        ?>
    <tbody>
    <tr>
      <form action="" method="POST">
     <td><?php echo $row['libid']; ?><input type="hidden" name="libid" id="libid" value="<?php echo $row['libid']; ?>"></td>
     <td><?php echo $row['sname']; ?></td>
     <td><?php echo $row['email']; ?></td>
     <td><?php echo $row['phone']; ?></td>
     <td><?php if($row['status']=="Approved"){ ?>
      <button type="button" class="btn btn-primary" disabled><?php echo $row['status']; ?></button>
    <?php }else{ ?>      <button type="button" class="btn btn-danger" disabled><?php echo $row['status']; ?></button>
    <?php } ?></td>
     
     <td><select name="status" class="form-control" id="status" onchange="this.form.submit()">
            <option>Select Any</option>
            <option value="Approved">Approv</option>
            <option value="Rejected">Reject</option>
            </select></td>
          </form>
    </tr>
  </tbody>
  <?php 
                  
                                            }
           
            
                  
                  ?>
</table>
                </div>
            </div>
            <!-- //forms 1 -->

            <!-- forms 2 -->
            
            <!-- //forms 2 -->

            <!-- horizontal forms-->
            <!-- forms 3 -->
            
            <!-- //forms 3 -->
            <!-- //horizontal forms-->

            <!-- supported elements -->
            <!--  -->
            
            <!-- // -->
            <!-- supported elements -->

        </section>
        <!-- //forms -->
        </section>
        <!-- //forms  -->

    </div>
    <!-- //content -->

</div>
<!-- main content end-->
</section>
<!--footer section start-->
<?php include("footer.php"); ?>